# -*- coding: utf-8 -*-
"""
Created on Mon Jun 16 10:28:19 2025

@author: maure
"""

""" This algorithm reprodudes a card trick
K: king
Q: queen
C, H, S, D : clubs ♣ , hearts ♥, spades ♠, diamonds ♦"""



#!!!cards= # list containing cards

print('Chose a card : ', cards)


def present_cards(cards, spec_answer, even_round):
    """ Function that presents """
    top_cards=
    bottom_cards=
    if even==True:
        if spec_answer=='yes':
            
            
        else:
            
    elif even==False:
        if spec_answer=='yes':
            
            
        else:
    return cards
        
#%% Round 1 
# 

print('\n Round 1 \n')
answer1=

present_cards(cards, answer1, True)
    
#%% Round 2    
print('\n Round 2 \n')  
print([cards[j] for j in odd])

answer2=
present_cards(cards, answer2, False)

#%% Round3    
print('\n Round 3 \n')    
print([cards[j] for j in odd])
answer3=

top_cards=[cards[j] for j in odd]
bottom_cards=[cards[j] for j in even]
present_cards(cards, answer3, True)

    
#%% Reveal
print(' \n\n Reveal')  
time.sleep(2)  # Pause for 2 seconds 

# First shuffle : separate the cards into even and odds and reverse order

#%%
#Second Shuffle
