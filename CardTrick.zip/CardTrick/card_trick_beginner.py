# -*- coding: utf-8 -*-
"""
Created on Mon Jun 16 10:28:19 2025

@author: maure
"""

""" This algorithm reprodudes a card trick
K: king
Q: queen
C, H, S, D : clubs ♣ , hearts ♥, spades ♠, diamonds ♦"""

import time

#!!!cards= # list containing cards

print('Chose a card : ', cards)

#%% Round 1 
# Check if a card in even or odd and separate them in two lists
even=[]
odd=[]
for i in range(0, len (cards)):
    if : #!!!!
        even.append(i)
    else:
        odd.append(i)

print('\n Round 1 \n')
print([cards[j] for j in odd]) 

answer1=

# If the answer is yes, the odd cards (presented to the spectator goes on the bottom)
if answer1=='yes':
    
    top_cards=[cards[j] for j in odd]
    bottom_cards=[cards[j] for j in even]
    cards=top_cards+bottom_cards
    # print(cards)
else:
    top_cards=[cards[j] for j in odd]
    bottom_cards=[cards[j] for j in even]
    cards=bottom_cards+top_cards
#%% Round 2    
print('\n Round 2 \n')  
print([cards[j] for j in odd])

answer2=
if answer2=='yes':
    
    top_cards=[cards[j] for j in odd]
    bottom_cards=[cards[j] for j in even]
    cards=bottom_cards+top_cards
#!!!!    
else:

#%% Round3    
print('\n Round 3 \n')    
print([cards[j] for j in odd])
answer3=

top_cards=[cards[j] for j in odd]
bottom_cards=[cards[j] for j in even]
#!!!!
if answer3=='yes':
    

    
#%% Reveal
print(' \n\n Reveal')  
time.sleep(2)  # Pause for 2 seconds 
left_pile=[cards[j] for j in even][::-1]
right_pile=[cards[j] for j in odd][::-1]
if right_pile[-1][0]=='K':
    head='KING'
else:
    head='QUEEN'
print('\nI sense you chose a ', head)
time.sleep(2)  # Pause for 2 seconds

left_pile2=[left_pile[j] for j in even[0:2]][::-1]
right_pile2=[left_pile[j] for j in odd[0:2]][::-1]
if (right_pile2[-1][1]=='♠')or (right_pile2[-1][1]=='♣'):
    color='BLACK'
else:
    color='RED'    
print('\nSomething tells me it\'s a', color, 'card')
time.sleep(2)  # Pause for 2 seconds
print('\nYour card is : ', left_pile2[0])
input('\nPress \'Enter\' to close this tab ')